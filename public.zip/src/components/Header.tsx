import { Link, useLocation, useNavigate } from "react-router-dom";
import { company } from "@/config/company";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

const navItems = [
  { label: company.nav.home, id: "home" },
  { label: company.nav.about, id: "about" },
  { label: company.nav.contact, id: "contact" },
];

const Header = () => {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    setOpen(false);
  }, [location.pathname, location.hash]);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleNavClick = (id: string) => {
    if (location.pathname === "/") {
      scrollToSection(id);
      return;
    }

    navigate(`/#${id}`);
  };

  const isItemActive = (id: string) => {
    if (location.pathname !== "/") return false;
    if (id === "home") return !location.hash || location.hash === "#home";
    return location.hash === `#${id}`;
  };

  return (
    <header className="sticky top-0 z-50 border-b border-border/85 bg-background/90 backdrop-blur-md">
      <div className="site-container flex h-[72px] items-center justify-between">
        <Link
          to="/"
          className="inline-flex min-h-11 items-center rounded-[14px] px-1 hover:opacity-90"
        >
          <img
            src="/AllyExporter-logo.png"
            alt={company.displayName}
            className="h-[22px] w-auto sm:h-[26px] lg:h-[30px]"
            loading="eager"
            decoding="async"
          />
        </Link>

        <nav aria-label="Main navigation" className="hidden items-center gap-2 md:flex">
          {navItems.map((item) => {
            const active = isItemActive(item.id);
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavClick(item.id)}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "inline-flex min-h-11 items-center rounded-[14px] border px-4 text-sm font-medium transition-colors",
                  active
                    ? "border-primary/55 bg-primary/10 text-primary"
                    : "border-transparent text-muted-foreground hover:border-border hover:text-foreground",
                )}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        <button
          type="button"
          onClick={() => setOpen((prev) => !prev)}
          className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-[14px] border border-border bg-card text-muted-foreground hover:border-primary/35 hover:text-foreground md:hidden"
          aria-label="Toggle navigation menu"
          aria-expanded={open}
          aria-controls="mobile-navigation"
        >
          {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
        </button>
      </div>

      {open && (
        <nav id="mobile-navigation" aria-label="Mobile navigation" className="section-divider bg-background md:hidden">
          <div className="site-container grid gap-2 py-3">
            {navItems.map((item) => {
              const active = isItemActive(item.id);
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavClick(item.id)}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "inline-flex min-h-11 items-center rounded-[14px] border px-4 text-sm font-medium transition-colors",
                    active
                      ? "border-primary/55 bg-primary/10 text-primary"
                      : "border-border/90 text-muted-foreground hover:border-primary/35 hover:text-foreground",
                  )}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </nav>
      )}
    </header>
  );
};

export default Header;
